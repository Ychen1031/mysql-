<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "訂購單";

// 建立連接
$conn = new mysqli($servername, $username, $password, $dbname);

// 檢查連接
if ($conn->connect_error) {
    die("連接失敗: " . $conn->connect_error);
}

// 獲取表單資料
$name = $_POST['name'];
$drink = $_POST['drink'];
$size = $_POST['size'];
$sugar = $_POST['sugar'];
$ice = $_POST['ice'];

// 插入資料到資料庫
$sql = "INSERT INTO orders (name, drink, size, sugar, ice) VALUES ('$name', '$drink', '$size', '$sugar', '$ice')";

if ($conn->query($sql) === TRUE) {
    echo "訂單提交成功";
} else {
    echo "錯誤: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>